from django.apps import AppConfig


class MalaysiaAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'malaysia_app'
